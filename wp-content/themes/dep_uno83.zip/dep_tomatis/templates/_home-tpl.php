<?php

/*
  Template Name: Home Template
*/

	get_template_part('includes/header');

		get_template_part('includes/home/slider-form');

		get_template_part('includes/home/publico');

		get_template_part('includes/home/slider-estilos');

		get_template_part('includes/home/renders');

		get_template_part('includes/home/ubicacion');

		//get_template_part('includes/home/mantenimiento');

	get_template_part('includes/footer');
