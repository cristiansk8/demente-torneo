<footer class="container site-footer text-center">
<img src="http://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/Landing-183-13ago2019-cristian-25.png" alt="" width="200px" height="auto">
		  	  <div class="chatwa footer navbar-fixed-bottom text-left">
			 <a class="whatsapp-movil" href="whatsapp://send/?phone=573115072193&text=">
				<img src="https://conjuntolima.com/wp-content/uploads/2019/08/220236.png" alt="" width="55px" height="55px">
				  <h4>¡ESCRÍBENOS YA!</h4>
			  </a>
			  <a class="whatsapp-web" href="https://web.whatsapp.com/send/?phone=573115072193&text=">
		     	<img src="https://conjuntolima.com/wp-content/uploads/2019/08/220236.png" alt=""width="80px" height="auto">
				   <h4>¡ESCRÍBENOS YA!</h4>
	         </a>
	  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
