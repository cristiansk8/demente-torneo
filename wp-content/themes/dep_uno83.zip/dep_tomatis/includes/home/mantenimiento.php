<div class="container-fluid" style="background-image:url(https://edificiouno83.com/wp-content/uploads/2019/08/fondo1.jpg); height:750px">
  <div class="row text-left logo">
      <img src="https://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/logo-uno83.png" alt="" width="300px" height="auto">
  </div>
  <div class="row">
    <div class="col-md-6">

    </div>
    <div class="col-md-4 formulario-contacto">
      <h3 id="text-form">
         ¿QUIERES SABER MÁS <span>SOBRE TU NUEVO HOGAR</span> ?
     </h3>
     <div class="">
       <?php echo do_shortcode('[contact-form-7 id="16" title="formulario"]'); ?>
     </div>
  </div>
  <div class="col-md-2">

  </div>
</div>
