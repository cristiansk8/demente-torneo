<section id="publico">
  <div class="container-fluid">
  	<div class="row">
  		<div class="col-md-2">

  		</div>
  		<div class="col-md-1 publico">
      <a href="#familia"><u>familia</u></a>
  		</div>
  		<div class="col-md-1 publico">
        <a href="#deportistas"><u>deportistas</u></a>
  		</div>
  		<div class="col-md-1 publico">
  		  <a href="#home-office"><u>home office</u></a>
  		</div>
  		<div class="col-md-1 publico">
  			<a href="#mascotas"><u>mascotas</u></a>
  		</div>
  		<div class="col-md-1 publico">
  			<a href="#influencer"><u>influencer</u></a>
  		</div>
  		<div class="col-md-1 publico">
  			<a href="#moda"><u>moda</u></a>
  		</div>
  		<div class="col-md-1 publico">
  			<a href="#musico"><u>músico</u></a>
  		</div>
  		<div class="col-md-1 publico">
  			<a href="#todos"><u>El espacio de todos</u></a>
  		</div>
  		<div class="col-md-2 publico">

  		</div>
  	</div>

  </div>

</section>
