<section>
  <div class="">
    <div class="row">
      <div class="">
        <div class="">

        </div>
        <div class="col-md-3 formulario-contacto">
          <h3 id="text-form">
             ¿QUIERES SABER MÁS <span>SOBRE TU NUEVO HOGAR</span> ?
         </h3>
         <div class="">
           <?php echo do_shortcode('[contact-form-7 id="16" title="formulario"]'); ?>
         </div>

        </div>
        <div class="col-md-1">

        </div>
      </div>
    </div>
  </div>
</section>
