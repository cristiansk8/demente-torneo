<section id="slider-form">
  <div class="slider-form">

    <div class="container-fluid" style="background-image:url(https://edificiouno83.com/wp-content/uploads/2019/09/banner-uno83.png); height:auto;background-size: cover;">
      <div class="row text-left logo">
          <img src="https://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/logo-uno83.png" alt="" width="300px" height="auto">
      </div>
      <div class="row">
        <div class="col-md-8 text-slider text-center">
          <div class="text-big">
            <h1>APARTAMENTOS <span>DESDE</span> $152'000,000</h1>
          </div>
          <div class="oferta"> <span>precios de lanzamiento</span> </div>
        </div>
        <div class="col-md-3 form-gral">
          <div class=" formulario-contacto">
            <h3>
                ¿QUIERES SABER<br> MÁS SOBRE <br><span>TU NUEVO HOGAR</span> ?
           </h3>
          </div>

         <div class="">
           <script charset="utf-8" type="text/javascript" src="//js.hsforms.net/forms/shell.js"></script>
<script>
  hbspt.forms.create({
	portalId: "6326850",
	formId: "fcb014e8-6db9-4033-b835-224c680bff5f"
});
</script>
         </div>

        </div>
        <div class="col-md-1">

        </div>
      </div>
    </div>

    <div class="container-fluid" style="background-image:url(http://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/Landing-183-13ago2019-cristian-03.jpg); height:auto;background-size: cover;">
      <div class="row text-left logo">
          <img src="https://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/logo-uno83.png" alt="" width="300px" height="auto">
      </div>
      <div class="row">
        <div class="col-md-8 text-slider">
          <div class="text-big">
            <h1>COMPRAR APTO EN <br><span>BOGOTÁ SÍ SE PUEDE</span></h1>
          </div>

<div class="oferta"> <span>precios de lanzamiento</span> </div>
        </div>
        <div class="col-md-3 form-gral">
          <div class=" formulario-contacto">
            <h3>
                ¿QUIERES SABER<br> MÁS SOBRE <br><span>TU NUEVO HOGAR</span> ?
           </h3>
          </div>

         <div class="">
           <script charset="utf-8" type="text/javascript" src="//js.hsforms.net/forms/shell.js"></script>
<script>
  hbspt.forms.create({
 portalId: "6326850",
 formId: "fcb014e8-6db9-4033-b835-224c680bff5f"
});
</script>
         </div>

        </div>
        <div class="col-md-1">

        </div>
      </div>
    </div>

    <div class="container-fluid" style="background-image:url(http://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/Landing-183-13ago2019-cristian-02.jpg); height:auto;background-size: cover;">
      <div class="row text-left logo">
          <img src="https://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/logo-uno83.png" alt="" width="300px" height="auto">
      </div>
      <div class="row">
        <div class="col-md-8 text-slider ">
          <div class="text-big text-rosa">
            <h1> <span>TÚ PERSONALIZAS</span>  <br>TU APARTAMENTO</h1>
          </div>

            <div class="oferta"> <span>precios de lanzamiento</span> </div>
        </div>

        <div class="col-md-3 form-gral">
          <div class=" formulario-contacto">
            <h3>
                ¿QUIERES SABER<br> MÁS SOBRE <br><span>TU NUEVO HOGAR</span> ?
           </h3>
          </div>

         <div class="">
           <script charset="utf-8" type="text/javascript" src="//js.hsforms.net/forms/shell.js"></script>
<script>
  hbspt.forms.create({
  portalId: "6326850",
  formId: "fcb014e8-6db9-4033-b835-224c680bff5f"
});
</script>
         </div>

        </div>
        <div class="col-md-1">

        </div>
      </div>
    </div>

    <div class="container-fluid" style="background-image:url(http://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/Landing-183-13ago2019-cristian-03.jpg); height:auto;background-size: cover;">
      <div class="row text-left logo">
          <img src="https://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/logo-uno83.png" alt="" width="300px" height="auto">
      </div>
      <div class="row">
        <div class="col-md-8 text-slider">
          <div class="text-big">
            <h1>TÚ LO ESCOGES<br><span>TÚ LO PERSONALIZAS</span></h1>
          </div>

<div class="oferta"> <span>precios de lanzamiento</span> </div>
        </div>
        <div class="col-md-3 form-gral">
          <div class=" formulario-contacto">
            <h3>
                ¿QUIERES SABER<br> MÁS SOBRE <br><span>TU NUEVO HOGAR</span> ?
           </h3>
          </div>

         <div class="">
           <script charset="utf-8" type="text/javascript" src="//js.hsforms.net/forms/shell.js"></script>
<script>
  hbspt.forms.create({
  portalId: "6326850",
  formId: "fcb014e8-6db9-4033-b835-224c680bff5f"
});
</script>
         </div>

        </div>
        <div class="col-md-1">

        </div>
      </div>
    </div>

  </div>



</section>
