<section id="ubicacion">
  <div class="container-fluid ubicacion">
    <div class="row">
      <div class="col-md-8 bl-mapa">
        <img src="https://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/mapa-uno83.png" alt="" width="100%" height="auto">
      </div>
      <div class="col-md-4 info-ubicacion">
        <h2>nuestra<br>ubicación</h2>
        <div class="sala-negocios">
          <h2>sala de negocios</h2>
          <div class="text-center bl-redes">
            <div class="wa">
              <h2>311 507 2193</h2>
              <img src="https://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/whatsapp.png" alt="" width="45px" height="45px">
            </div>
            <div class="redes">
              <div class="insta">
                <img src="https://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/instagram.png" alt="" width="45px" height="auto">
                <p>/edificiouno83</p>
              </div>
              <div class="face">
                <img src="https://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/facebook.png" alt="" width="45px" height="auto">
                <p>/edificiouno83</p>
              </div>
            </div>
          </div>
        </div>
        <div class="waze">
          <img src="https://depura-creatividad.com/landinguno83/wp-content/uploads/2019/08/waze-y-direccion.png" alt="" width="100%" height="auto">
        </div>
      </div>
    </div>
  </div>
</section>
